Thanks for downloading our app!

Sorry to say that this app has not been maintained and was only a 2nd year project of ours and may have so many bugs. 

This is just for our demo project and we have managed to implement transactions and other features. For now the api is depreciated and maybe in the future I will update this app.


Best Regards,
Christopher Castro :)))